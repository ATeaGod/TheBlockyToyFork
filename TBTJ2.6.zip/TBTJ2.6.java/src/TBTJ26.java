import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class TBTJ26 extends JPanel implements ActionListener, MouseListener, MouseMotionListener {
    private static final int G = 10, EMPTY = 0, SAND = 1, WATER = 2, WALL = 3, FIRE = 4;
    private int rows = 60, cols = 80, curElem = SAND;
    private final int[][] grid = new int[rows][cols];
    private boolean paused = false;
    private final Timer timer;

    public TBTJ26() {
        addMouseListener(this);
        addMouseMotionListener(this);
        timer = new Timer(50, this);
        timer.start();
        initializeGrid();
    }

    private void initializeGrid() {
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                grid[r][c] = (r == 0 || r == rows - 1 || c == 0 || c == cols - 1) ? WALL : EMPTY;
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!paused) {
            updateParticles();
            repaint();
        }
    }

    private void updateParticles() {
        for (int r = rows - 2; r >= 0; r--) {
            for (int c = 0; c < cols; c++) {
                switch (grid[r][c]) {
                    case SAND -> moveElement(r, c, r + 1, c);
                    case WATER -> moveWater(r, c);
                    case FIRE -> moveFire(r, c);
                }
            }
        }
    }

    private boolean moveElement(int r, int c, int newR, int newC) {
        if (newR < rows && newC < cols && newR >= 0 && newC >= 0 && grid[newR][newC] == EMPTY) {
            grid[newR][newC] = grid[r][c];
            grid[r][c] = EMPTY;
            return true;
        }
        return false;
    }

    private void moveWater(int r, int c) {
        if (moveElement(r, c, r + 1, c)) return;
        if (moveElement(r, c, r + 1, c - 1)) return;
        if (moveElement(r, c, r + 1, c + 1)) return;
    }

    private void moveFire(int r, int c) {
        if (moveElement(r, c, r - 1, c)) return;
        if (moveElement(r, c, r - 1, c - 1)) return;
        if (moveElement(r, c, r - 1, c + 1)) return;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                g.setColor(getColor(grid[r][c]));
                g.fillRect(c * G, r * G, G, G);
            }
        }
    }

    private Color getColor(int elem) {
        return switch (elem) {
            case SAND -> Color.YELLOW;
            case WATER -> Color.BLUE;
            case WALL -> Color.GRAY;
            case FIRE -> Color.ORANGE;
            default -> Color.BLACK;
        };
    }

    @Override
    public void mousePressed(MouseEvent e) { updateGrid(e.getX(), e.getY()); }
    @Override public void mouseDragged(MouseEvent e) { mousePressed(e); }
    @Override public void mouseReleased(MouseEvent e) {}
    @Override public void mouseMoved(MouseEvent e) {}
    @Override public void mouseClicked(MouseEvent e) {}
    @Override public void mouseEntered(MouseEvent e) {}
    @Override public void mouseExited(MouseEvent e) {}

    private void updateGrid(int x, int y) {
        int col = x / G, row = y / G;
        if (col < cols && row < rows) {
            grid[row][col] = curElem;
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("The Blocky Toy Java Edition 2.6");
        TBTJ26 game = new TBTJ26();
        frame.add(game);

        JPanel panel = new JPanel();
        String[] elements = {"Clear", "Erase", "Sand", "Water", "Wall", "Fire"};
        int[] elementIds = {EMPTY, EMPTY, SAND, WATER, WALL, FIRE};

        for (int i = 0; i < elements.length; i++) {
            int elementId = elementIds[i];
            JButton button = new JButton(elements[i]);
            button.addActionListener(e -> {
                if (elementId == EMPTY && "Clear".equals(e.getActionCommand())) {
                    for (int r = 0; r < game.rows; r++)
                        for (int c = 0; c < game.cols; c++)
                            game.grid[r][c] = EMPTY;
                } else {
                    game.curElem = elementId;
                }
            });
            panel.add(button);
        }

        JButton pauseButton = new JButton("Pause");
        pauseButton.addActionListener(e -> game.paused = !game.paused);
        panel.add(pauseButton);

        frame.add(panel, BorderLayout.SOUTH);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setVisible(true);
    }
}
